let $ = document;
let h2 = $.querySelector("h2");
let input = $.querySelector("input");
let button = $.querySelector("button");

button.addEventListener("click", () => {
    let alphabets = [..."abcdefghijklmnopqrstuvwxyz".split(""), " " , ..."abcdefghijklmnopqrstuvwxyz".toUpperCase().split("")];
    let value = input.value;
    let character = "";
    let index = 0;
    let i = 0;

    for (let item of value) {
        if (!(alphabets.includes(item))) {
            alphabets.push(item);
        }
    }

    h2.innerHTML = "";
    const interval = setInterval(() => {
        h2.innerHTML = character;
        h2.innerHTML += alphabets[index];
        if (alphabets[index] === value[i]) { 
            character += alphabets[index];
            if (i >= value.length - 1) {
                clearInterval(interval)
            } else {
                index = 0;
                i++;
                interval
            }
        }
        index++;
    }, 100);
})