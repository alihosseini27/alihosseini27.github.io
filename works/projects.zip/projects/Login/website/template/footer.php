<footer id="main-footer">
    <div class="footer-content">
        <div class="footer-column" id="about">
            <h3>درباره ما</h3>
            <p>سایت من</p>
        </div>
        <div class="footer-column" id="service">
            <h3>پیوندها</h3>
            <ul>
                <li><a href="register/login.php">ورود</a></li>
                <li><a href="register/signup.php">ثبت نام</a></li>
            </ul>
        </div>
        <div class="footer-column" id="contact">
            <h3>تماس با ما</h3>
            <p>آدرس: هنرستان باقرالعلوم</p>
            <p>تلفن: 09103404702</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>تمامی حقوق محفوظ است &copy; 2024</p>
    </div>
</footer>