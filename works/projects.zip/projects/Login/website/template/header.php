<header id="main-header">
    <h1 id="site-title">TM~Ali</h1>
    <nav id="main-nav">
        <ul>
            <li><a href="/website/index.php" class="nav-link">پنل کاربری</a></li>
            <li><a href="#about" class="nav-link">درباره ما</a></li>
            <li><a href="#service" class="nav-link">خدمات</a></li>
            <li><a href="#contact" class="nav-link">تماس با ما</a></li>
        </ul>
    </nav>
</header>