var $ = document;
let container = document.querySelector(".search-input");
let input = $.querySelector("input");
let box = $.querySelector(".autocom-box");
input.addEventListener('keyup',function search () {
    let value = input.value;
    if (value) {
        container.classList.add('active');
        let finds = suggestions.filter(function filter (suggestion) {
            return suggestion.toLowerCase().includes(value.toLowerCase());
        })
        suggestionGenerator(finds);
    } else {
        container.classList.remove('active');
    }
});
function suggestionGenerator (finds) {
    let lis = finds.map(function (suggestion) {
        return '<li>' + suggestion + '</li>'
    })
    if (lis.length) {
        let li = lis.join("");
        box.innerHTML = li;
        search();
    } else {
        box.innerHTML = '<li>' + input.value + '</li>';
        search();
    }
}
function search () {
    let lis = box.querySelectorAll("li");
    lis.forEach(function (li) {
        li.addEventListener('click',function (event) {
            input.value = event.target.textContent;
            container.classList.remove("active");
        })
    })
}